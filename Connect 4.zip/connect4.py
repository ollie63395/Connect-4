import random
import os
import math 
import time

def clear_screen():
	"""
	Clears the terminal for Windows and Linux/MacOS.

	:return: None
	"""
	os.system('cls' if os.name == 'nt' else 'clear')


def print_rules():
	"""
	Prints the rules of the game.

	:return: None
	"""
	print("================= Rules =================")
	print("Connect 4 is a two-player game where the")
	print("objective is to get four of your pieces")
	print("in a row either horizontally, vertically")
	print("or diagonally. The game is played on a")
	print("6x7 grid. The first player to get four")
	print("pieces in a row wins the game. If the")
	print("grid is filled and no player has won,")
	print("the game is a draw.")
	print("=========================================")


def validate_input(prompt: str, valid_inputs: list) -> str:
	"""
	Repeatedly ask user for input until they enter an input
	within a set valid of options.

	:param prompt: The prompt to display to the user, string.
	:param valid_inputs: The range of values to accept, list
	:return: The user's input, string.
	"""
	user_input = input(prompt)

	while True:
		# Check to see if the user input is within the provided valid inputs
		if user_input in valid_inputs:
			return str(user_input)
		else:
			print("Invalid input, please try again.")
			user_input = input(prompt)


def create_board():
	"""
	Returns a 2D list of 6 rows and 7 columns to represent
	the game board. Default cell value is 0.

	:return: A 2D list of 6x7 dimensions.
	"""
	# Create an empty list of 6 rows
	board_list = [None] * 6

	# Append new set of lists to board list to create a 2D matrix of 6x7
	for i in range(len(board_list)):
		board_list[i] = [0]*7
	return board_list

def print_board(board):
	"""
	Prints the game board to the console.

	:param board: The game board, 2D list of 6x7 dimensions.
	:return: None
	"""
	# Constant variables
	empty_cell = "   "
	p1_cell = " X "
	p2_cell = " O "
	row = '|'

	print("========== Connect4 =========\nPlayer 1: X       Player 2: O\n\n  1   2   3   4   5   6   7")
	# Reads the 2D matrix and prints out to the board with corresponding player information
	for i in range(len(board)):
		print(" --- --- --- --- --- --- ---")
		for j in range(len(board[i])):
			if board[i][j] == 0:
				token = empty_cell
				cell = token + "|"
				row += cell
			elif board[i][j] == 1:
				token = p1_cell
				cell = token + "|"
				row += cell
			elif board[i][j] == 2:
				token = p2_cell
				cell = token + "|"
				row += cell
			else:
				return None
		print(row)
		row = '|'
	print(" --- --- --- --- --- --- ---\n=============================")


def drop_piece(board, player: int, column: int) -> bool:
	"""
	Drops a piece into the game board in the given column.
	Please note that this function expects the column index
	to start at 1.

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player who is dropping the piece, int.
	:param column: The index of column to drop the piece into, int.
	:return: True if piece was successfully dropped, False if not.
	"""
	# Return False if the first row of the input column is already chosen
	if board[0][column - 1] != 0:
		return False
	
	row = 1
	while True:
		# Checks if a lower row is empty, if so, continue check else, place token in previous row.
		if row == len(board) or board[row][column - 1] != 0:
			board[row - 1][column - 1] = player
			return True
		else:
			row += 1

def execute_player_turn(player: int, board) -> int:
	"""
	Prompts user for a legal move given the current game board
	and executes the move.

	:return: Column that the piece was dropped into, int.
	"""
	while True:
	# Repeatedly prompt the message to the user until they have inputted a valid column selection (where the column is not full)
		user_select = int(validate_input("Player " + str(player) + ", please enter the column you would like to drop your piece into: ",["1", "2", "3", "4", "5", "6", "7"]))
		if drop_piece(board, player, user_select) == False:
			print("That column is full, please try again.")
			continue
		else:
			break
	return int(user_select)


def end_of_game(board) -> int:
	"""
	Checks if the game has ended with a winner
	or a draw.

	:param board: The game board, 2D list of 6 rows x 7 columns.
	:return: 0 if game is not over, 1 if player 1 wins, 2 if player 2 wins, 3 if draw.
	"""
	# Comment?
	if vertical_check(board,1) == True or horizontal_check(board,1) == True or right_diagonal_check(board,1) == True or left_diagonal_check(board,1) == True:
		return 1
	elif vertical_check(board,2) == True or horizontal_check(board,2) == True or right_diagonal_check(board,2) == True or left_diagonal_check(board,2) == True:
		return 2
	elif draw_check(board) == False:
		return 0
	else:
		return 3


# Helper functions for end_of_game to check possible wins
def vertical_check(board,player_index: int) -> bool:
	"""
	Checks for any possible vertical winning combination

	:param board: The game board, 2D list of 6 rows x 7 columns
	:param player_index: Representing player 1 or 2

	:return: True if player_index has won the game
	"""
	# Until i reaches half of the board vertical length
	for i in range(int(len(board)/2)):
		# Until x reaches the board length
		for x in range(len(board[i])):
			if board[i][x] == player_index and board[i+1][x] == player_index and board[i+2][x] == player_index and board[i+3][x] == player_index:
				return True

def horizontal_check(board,player_index: int) -> bool:
	"""
	Checks for any possible horizontal winning combination

	:param board: The game board, 2D list of 6 rows x 7 columns
	:param player_index: Representing player 1 or 2

	:return: True if player_index has won the game
	"""
	# Until i reaches the board length
	for i in range(len(board)):
		# Until x reaches half of the board horizontal length
		for x in range(math.ceil(len(board[i])/2)):
			if board[i][x] == player_index and board[i][x+1] == player_index and board[i][x+2] == player_index and board[i][x+3] == player_index: 
				return True

def right_diagonal_check(board,player_index: int) -> bool:
	"""
	Checks for any diagonal combination to the right
	
	:param board: The game board, 2D list of 6 rows x 7 columns
	:param player_index: Representing player 1 or 2

	:return: True if player_index has won the game
	"""
	# Until i and x reaches half of the board, index start from 0 and increment
	for i in range(int(len(board)/2)):
		for x in range(math.ceil(len(board[i])/2)):
			if board[i][x] == player_index and board[i+1][x+1] == player_index and board[i+2][x+2] == player_index and board[i+3][x+3] == player_index:
				return True

def left_diagonal_check(board,player_index: int) -> bool:
	"""
	Checks for any diagonal combination to the left
	
	:param board: The game board, 2D list of 6 rows x 7 columns
	:param player_index: Representing player 1 or 2

	:return: True if player_index has won the game
	"""
	# Until i and x reaches half of the board, index start from -1 and decrement
	for i in range(int(len(board)/2)):
		x = -1
		while x >= -4:
			if board[i][x] == player_index and board[i+1][x-1] == player_index and board[i+2][x-2] == player_index and board[i+3][x-3] == player_index:
				return True
			
			x -= 1

def draw_check(board) -> bool:
	"""
	Checks whether the board is full
	
	:param board: The game board, 2D list of 6 rows x 7 columns

	:return: False if the board is not full, the game continues
	"""
	# Full if there is no 0's in the first row
	for i in range(len(board[0])):
		if board[0][i] == 0:
			return False

# End of defining the checking functions for end_of_game
	

def local_2_player_game():
	"""
	Runs a local 2 player game of Connect 4.

	:return: None
	"""
	#Constant Variables
	iter_count = 0
	p1 = 1
	p2 = 2
	board = create_board()

# Runs on a loop; prints out the board and input. Once executed, the move is printed onto the board.
# Loop ends when a player wins or a draw occurs.
	while True:
		# Refreshes terminal and prints board
		clear_screen()
		print_board(board)

		# Prints opposing players previous move
		if iter_count != 0:
			if iter_count == 0 or iter_count % 2 == 0:
				print("Player", p2, "dropped a piece into column", action)
			else:
				print("Player", p1, "dropped a piece into column", action)

		# Executes current player's move
		if iter_count == 0 or iter_count % 2 == 0:
			action = execute_player_turn(p1, board)
		else:
			action = execute_player_turn(p2, board)

		iter_count += 1

		# Checks current status of game
		if end_of_game(board) == 0:
			continue
		else:
			clear_screen()
			print_board(board)
			if end_of_game(board) == 1:
				print("Player 1 has won the game")
			elif end_of_game(board) == 2:
				print("Player 2 has won the game")
			elif end_of_game(board) == 3:
				print("Draw")
			break


def print_menu():
	"""
	Prints the menu to show options to selection

	:return: None
	"""
	print("=============== Main Menu ===============")
	print("Welcome to Connect 4!")
	print("1. View Rules")
	print("2. Play a local 2 player game")
	print("3. Play a game against the computer")
	print("4. Exit")
	print("=========================================")

	
def main():
	"""
	Defines the main application loop.
    User chooses a type of game to play or to exit.

	:return: None
	"""
	# Runs on a loop to repeatedly return back to menu 
	# Includes the addition of the time module to access sleep function which allows a 
	# delay between execution of code.
	while True:
		clear_screen()
		print_menu()
		user_input = int(input("Select an option: "))
		clear_screen()
		
		if user_input == 1:
			print_rules()
			time.sleep(10)
		elif user_input == 2:
			local_2_player_game()
			time.sleep(3)
		elif user_input == 3:
			game_against_cpu()
			time.sleep(3)
		elif user_input == 4:
			break


def cpu_player_easy(board, player):
	"""
	Executes a move for the CPU on easy difficulty. This function 
	plays a randomly selected column.

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.
	:return: Column that the piece was dropped into, int.
	"""
	# Inputs a random value from possible columns, if not possible choose another value else return that column number
	while True:
		ran_num = random.randrange(1,8)
		if drop_piece(board, player, ran_num) is False:
			continue
		else:
			break
	return ran_num


def cpu_player_medium(board, player: int) -> int:
	"""
	Executes a move for the CPU on medium difficulty.
	It first checks for an immediate win and plays that move if possible. 
	If no immediate win is possible, it checks for an immediate win 
	for the opponent and blocks that move. If neither of these are 
	possible, it plays a random move.

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.
	:return: Column that the piece was dropped into, int.
	"""
	# Initially, runs on two iterations for checks
	# First check for a win and second check for a block
	for action in range(2):
		a_player = player
		if action == 1:
			if player == 1:
				# cpu is player 1, human is player 2
				a_player = player+1
			else:
				# human is player 1, cpu is player 2
				a_player = player-1

		vert_win_col = med_vert_check(board, a_player)
		hori_win_col = med_hori_check(board, a_player)
		right_dia_win_col = med_right_dia_check(board, a_player)
		left_dia_win_col = med_left_dia_check(board, a_player)

		if vert_win_col != None:
			drop_piece(board, player, vert_win_col)
			return vert_win_col

		elif hori_win_col != None:
			drop_piece(board, player, hori_win_col)
			return hori_win_col

		elif right_dia_win_col != None:
			drop_piece(board, player, right_dia_win_col)
			return right_dia_win_col

		elif left_dia_win_col != None:
			drop_piece(board, player, left_dia_win_col)
			return left_dia_win_col
	
	ran_col = random_move(board, player)
		
	return ran_col

# Checks for all winning possibilities (Helper Functions)
def med_vert_check(board,player_index: int) -> int:
	"""
	Checks for any possible vertical winning combination
	"""
	# Until y reaches half of the board vertical length
	for y in range(-1,int(len(board)/-2), -1):
		# Until x reaches the board length
		for x in range(len(board[y])):

			if board[y][x] == player_index and board[y-1][x] == player_index and board[y-2][x] == player_index and board[y-3][x] == 0:
				winning_column = x+1
				return winning_column

def med_hori_check(board,player_index: int) -> int:
	"""
	Checks for any possible horizontal winning combination
	"""
	# Until y reaches the board length
	for y in range(-1,(len(board)*-1)-1, -1):
		# Until x reaches half of the board horizontal length
		for x in range(math.ceil(len(board[y])/2)):

			horizontal_list = []
			for i in range(4):
				horizontal_list.append(board[y][x + i])
				
			if horizontal_list.count(player_index) == 3 and (0 in horizontal_list):
				winning_column = horizontal_list.index(0) + x + 1
				return winning_column

def med_right_dia_check(board,player_index: int) -> int:
	"""
	Checks for any diagonal combination to the right (starting from bottom)
	"""
	# Until y and x reaches half of the board, index start from 0 and increment
	for y in range(-1,int(len(board)/-2),-1):
		for x in range(math.ceil(len(board[y])/2)):

			horizontal_list = []
			for i in range(4):
				horizontal_list.append(board[y + i][x + i])

			if horizontal_list.count(player_index) == 3 and (0 in horizontal_list):
				winning_column = horizontal_list.index(0) + x + 1
				return winning_column

def med_left_dia_check(board,player_index: int) -> int:
	"""
	Checks for any diagonal combination to the left
	"""
	# Until y and x reaches half of the board, index start from -1 and decrement
	for y in range(-1,int(len(board)/-2)-1,-1):
		for x in range(-1,math.floor(len(board[y])/-2)-1,-1):

			horizontal_list = []
			for i in range(4):
				horizontal_list.append(board[y-i][x-i])

			if horizontal_list.count(player_index) == 3 and (0 in horizontal_list):
				winning_column = horizontal_list.index(0) + (len(board) + x) - 1
				return winning_column


def random_move(board, player):
	"""
	Plays a random move.

	:para board: The game board, 2D list of 6x7 dimensions.
	:para player: The player whose turn it is, integer value of 1 or 2.
	"""
	while True:
		ran_num = random.randrange(1,8)
		if drop_piece(board, player, ran_col) is True:
			break
	return ran_num


def cpu_player_hard(board, player, iter_count) -> int:
	"""
	Executes a move for the CPU on hard difficulty.
	This function creates a copy of the board to simulate moves.
    
	<1. Make the first 3 moves in the middle column (for cpu) to take middle control
		-> This is because the more tokens are there in the middle column, the more interesction combinations will be created

	 2. Throughout every move, always anticipate whether the player is planning for a winning combination (indirect win)
	 	-> If player has 

	 3. The best move will always be the position that could create the most number of connections with other tokens
	 	-> Therefore, we use the intersection check functions to detect the best move

	 4. Of course, the cpu should also check if there is an immediate winning chance (same as cpu_player_medium)>

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.
	:return: Column that the piece was dropped into, int.
	"""
	anticipate = anticipate_block(board, player)

	if iter_count < 3:
		middle_column = 3
		
		if anticipate != None:
			drop_piece(board, player, anticipate)
			return anticipate
		
		drop_piece(board, player, middle_column)
		return middle_column

	else:
		win = immediate_win(board,player)
		intersect = find_best_intersection(board, player)
		block = immediate_block(board, player)

		if win != None:
			drop_piece(board, player, win)
			return win
			
		elif block != None:
			drop_piece(board, player, block)
			return block

		elif anticipate != None:
			drop_piece(board, player, anticipate)
			return anticipate

		elif intersect != None: 
			drop_piece(board, player, intersect)
			return intersect

		else:
			rand_col = random_move(board, player)
			return rand_col

def immediate_win(board, player_index):
	vert_win_col = med_vert_check(board, player)
	hori_win_col = med_hori_check(board, player)
	right_dia_win_col = med_right_dia_check(board, player)
	left_dia_win_col = med_left_dia_check(board, player)

	if vert_win_col != None:
		return vert_win_col

	elif hori_win_col != None:
		return hori_win_col

	elif right_dia_win_col != None:
		return right_dia_win_col

	elif left_dia_win_col != None:
		return left_dia_win_col
	
	return None

def immediate_block(board, player_index):
	if player_index == 1:
		player = 2
	else:
		player = 1

	vert_win_col = med_vert_check(board, player)
	hori_win_col = med_hori_check(board, player)
	right_dia_win_col = med_right_dia_check(board, player)
	left_dia_win_col = med_left_dia_check(board, player)

	if vert_win_col != None:
		return vert_win_col

	elif hori_win_col != None:
		return hori_win_col

	elif right_dia_win_col != None:
		return right_dia_win_col

	elif left_dia_win_col != None:
		return left_dia_win_col
def anticipate_vert_check(board,player_index: int) -> int:
	"""
	This function checks for a planned winning move in the vertical direction
	If there are 2 indices of the same player_index in a row, that means the player is planning a winning move
	Therefore, the cpu will have to block that move beforehand

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.

	:returns: the column (base 1) of the planned next move, int.
	"""
	for y in range(-1,int(len(board)/-2)-2, -1):
		for x in range(len(board[y])):
			if board[y][x] == player_index and board[y-1][x] == player_index and board[y-2][x] == 0:
				indirect_winning_column = x+1
				return indirect_winning_column

def anticipate_hori_check(board,player_index: int) -> int:
	"""
	This function checks for a planned winning move in the horizontal direction
	If there are 2 indices of the same player_index in a row, that means the player is planning a winning move
	Therefore, the cpu will have to block that move beforehand

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.

	:returns: the column (base 1) of the planned next move, int.
	"""
	for y in range(-1,(len(board)*-1)-1, -1):
		for x in range(math.ceil(len(board[y])/2)+1):

			horizontal_list = []
			for i in range(3):
				horizontal_list.append(board[y][x + i])
				
			if horizontal_list.count(player_index) == 2 and (0 in horizontal_list):
				for a in range(y+6,len(board),1):
					if board[a][horizontal_list.index(0) + x] == 0:
						drop_check = False
					else:
						drop_check = True

				if drop_check == True:
					indirect_winning_column = horizontal_list.index(0) + x + 1
					return indirect_winning_column

def anticipate_right_dia_check(board,player_index: int) -> int:
	"""
	This function checks for a planned winning move in the right diagonal direction
	If there are 2 indices of the same player_index in a row, that means the player is planning a winning move
	Therefore, the cpu will have to block that move beforehand

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.

	:returns: the column (base 1) of the planned next move, int.
	"""
	for y in range(-1,(len(board)*-1)+1, -1):
		for x in range(int((math.ceil(len(board))/2))+1):

			diagonal_list = []
			for i in range(3):
				diagonal_list.append(board[y - i][x + i])

			if diagonal_list.count(player_index) == 2 and (0 in diagonal_list):
				for a in range(y+6,len(board),1):
					if board[a][diagonal_list.index(0) + x] == 0:
						drop_check = False
					else:
						drop_check = True

				if drop_check == True:
					indirect_winning_column = diagonal_list.index(0) + x + 1
					return indirect_winning_column

def anticipate_left_dia_check(board,player_index: int) -> int:
	"""
	This function checks for a planned winning move in the left diagonal direction
	If there are 2 indices of the same player_index in a row, that means the player is planning a winning move
	Therefore, the cpu will have to block that move beforehand

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player: The player whose turn it is, integer value of 1 or 2.

	:returns: the column (base 1) of the planned next move, int.
	"""
	for y in range(-1,(len(board)*-1)+1, -1):
		for x in range(-1,(len(board[y])*-1)+1,-1):

			diagonal_list = []
			for i in range(3):
				diagonal_list.append(board[y-i][x-i])

			if diagonal_list.count(player_index) == 2 and (0 in diagonal_list):
				for a in range(y+6,len(board),1):
					if board[a][x - diagonal_list.index(0) + 7] == 0:
						drop_check = False
					else:
						drop_check = True

				if drop_check == True:
					indirect_winning_column = x - diagonal_list.index(0) + 7 + 1
					return indirect_winning_column

def find_best_intersection(board,player_index: int) -> int:
	"""
	This function attempts to find the column that will generate the most number of intersections possible

	:param board: The game board, 2D list of 6x7 dimensions.
	:param player_index: Representing player 1 or 2
	
	:return: The column with the most intersection combinations
	"""
	# Variable for the highest intersection count
	current_intersection_count = 0

	# No vertical intersection is possible, so we'll skip the vertical check
	for x in range(len(board[0])):
		# Stores the number of intersections for each column's droppable index position
		intersection_compare = 0

		# If drop_piece is droppable, then start to detect the bottom_most index position starting from under
		if board[0][x + 1] == 0:

			index = -1
			found = False

			while found == False and index > (len(board)*-1):
				if board[index][x] == 0:
					found = True

					# Start to find intersection combinations once a droppable index postition has been found
					# intersection_compare increments for every successful intersection check
					if left_horizontal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1
					if right_horizontal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1
					if left_up_diagonal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1
					if left_down_diagonal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1
					if right_up_diagonal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1
					if right_down_diagonal_intersection(board,player_index,index,x) == 1:
						intersection_compare += 1

					# Replace the current highest intersection count with intersection_compare if intersection_compare has a higer value
					if intersection_compare >= current_intersection_count:
						current_intersection_count = intersection_compare

						# Columns of base 1 is used in drop_piece
						# Therefore, we add 1 to x in order to call the drop_piece function later on
						best_column = x+1
				else:
					index -= 1

		return best_column

def left_horizontal_intersection(board,player_index,index,left_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param left_border_index: the column index

	:returns: 1 if the position has a left intersection
	"""

	border_met = False
	intersect = False

	# This counts the number of positions for checking intersection (should not be more than 3)
	counter = 0

	# Iterates until the checking index gets out of range, or has found the intersection, or counter has reached 3
	while border_met == False and intersect == False and counter < 3:
		if left_border_index - 1 < 0:
			border_met = True
		else:
			# Intersection has been found
			if board[index][left_border_index-1] == player_index:
				intersect = True

			counter += 1
			left_border_index -= 1
	
	# Intersection is valid if the checking index is not out of range, and there is an index position with the same value as player_index
	if border_met == False and intersect == True:
		left_intersection_counter = 1
	else:
		left_intersection_counter = 0

	return left_intersection_counter

def left_up_diagonal_intersection(board,player_index,index,left_up_diagonal_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param left_up_diagonal_border_index: the column index

	:returns: 1 if the position has a left-up-diagonal intersection
	"""

	border_met = False
	intersect = False

	counter = 0
	
	while border_met == False and intersect == False and counter < 3:
		if left_up_diagonal_border_index - 1 < 0 or index - 1 < (len(board)*(-1)):
			border_met = True
		else:
			if board[index-1][left_up_diagonal_border_index-1] == player_index:
				intersect = True
			
			index -= 1
			counter += 1
			left_up_diagonal_border_index -= 1
	
	if border_met == False and intersect == True:
		left_up_diagonal_intersection_counter = 1
	else:
		left_up_diagonal_intersection_counter = 0

	return left_up_diagonal_intersection_counter


def left_down_diagonal_intersection(board,player_index,index,left_down_diagonal_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param left_down_diagonal_border_index: the column index

	:returns: 1 if the position has a left-down-diagonal intersection
	"""

	border_met = False
	intersect = False

	counter = 0
	
	while border_met == False and intersect == False and counter < 3:
		if left_down_diagonal_border_index - 1 < 0 or index - 1 < -1:
			border_met = True
		else:
			if board[index+1][left_down_diagonal_border_index-1] == player_index:
				intersect = True
			
			index += 1
			counter += 1
			left_down_diagonal_border_index -= 1
	
	if border_met == False and intersect == True:
		left_down_diagonal_intersection_counter = 1
	else:
		left_down_diagonal_intersection_counter = 0

	return left_down_diagonal_intersection_counter


def right_horizontal_intersection(board,player_index,index,right_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param right_border_index: the column index

	:returns: 1 if the position has a right intersection
	"""

	border_met = False
	intersect = False
	
	counter = 0
	
	while border_met == False and intersect == False and counter < 3:
		if right_border_index + 1 > len(board[0])-1:
			border_met = True
		else:
			if board[index][right_border_index+1] == player_index:
				intersect = True

			counter += 1
			right_border_index += 1
	
	if border_met == False and intersect == True:
		right_intersection_counter = 1
	else:
		right_intersection_counter = 0

	return right_intersection_counter

def right_up_diagonal_intersection(board,player_index,index,right_up_diagonal_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param right_up_diagonal_border_index: the column index

	:returns: 1 if the position has a right-up-diagonal intersection
	"""

	border_met = False
	intersect = False

	counter = 0
	
	while border_met == False and intersect == False and counter < 3:
		if right_up_diagonal_border_index + 1 > len(board[0])-1 or index - 1 < (len(board)*(-1)):
			border_met = True
		else:
			if board[index-1][right_up_diagonal_border_index+1] == player_index:
				intersect = True
			
			index -= 1
			counter += 1
			right_up_diagonal_border_index += 1
	
	if border_met == False and intersect == True:
		right_up_diagonal_intersection_counter = 1
	else:
		right_up_diagonal_intersection_counter = 0

	return right_up_diagonal_intersection_counter


def right_down_diagonal_intersection(board,player_index,index,right_down_diagonal_border_index):

	"""
	This function checks to see if a player_index has been detected 
	along the left, horizontal direction

	:param board: the connect4 board
	:param player_index: the player's token
	:param index: the row index
	:param right_down_diagonal_border_index: the column index

	:returns: 1 if the position has a right-down-diagonal intersection
	"""

	border_met = False
	intersect = False

	counter = 0
	
	while border_met == False and intersect == False and counter < 3:
		if right_down_diagonal_border_index + 1 > len(board[0]) or index + 1 > -1:
			border_met = True
		else:
			if board[index+1][right_down_diagonal_border_index+1] == player_index:
				intersect = True
			
		index += 1
		counter += 1
		right_down_diagonal_border_index += 1
	
	if border_met == False and intersect == True:
		right_down_diagonal_intersection_counter = 1
	else:
		right_down_diagonal_intersection_counter = 0

	return right_down_diagonal_intersection_counter

def anticipation_block(board, player_index):
	if player_index == 1:
		opp_player = 2
	else:
		opp_player = 1

	vert = anticipate_vert_check(board, opp_player)
	hori = anticipate_hori_check(board, opp_player)
	left_dia = anticipate_left_dia_check(board, opp_player)
	right_dia = anticipate_right_dia_check(board, opp_player)

	if vert != None:
		return vert
	if hori != None:
		return hori
	if left_dia != None:
		return left_dia
	if right_dia != None:
		return right_dia


def game_against_cpu():
	"""
	Runs a game of Connect 4 against the computer.

	:return: None
	"""
	clear_screen()
	print_difficulty_select()
	user_input = int(input("Input a difficulty: "))

	board = create_board()
	iter_count	= 0
	p1 = 1
	p2 = 2

	#Game loop
	while True:
		clear_screen()
		print_board(board)

		# Prints the previous move of the player and CPU
		if iter_count != 0:
			print("Player", p1, "dropped a piece into column", p_action)
			print("CPU dropped a piece into column", cpu_action)
		
		# Executes the Player and CPUs move
		p_action = execute_player_turn(p1, board)
		cpu_action = cpu_difficulty(user_input, p2, board, iter_count)

		iter_count += 1
		
		# Checks the current status of the game
		if end_of_game(board) == 0:
			continue
		else:
			clear_screen()
			print_board(board)
			if end_of_game(board) == 1:
				print("Player 1 has won the game")
			elif end_of_game(board) == 2:
				print("CPU has won the game")
			elif end_of_game(board) == 3:
				print("Draw")
			break

#helper functions
def print_difficulty_select():
	print("========== Difficulty Selector ==========")
	print("1. Easy Mode")
	print("2. Medium Mode")
	print("3. Hard Mode")
	print("=========================================")

def cpu_difficulty(difficulty, player, board, iter_count):
	if difficulty == 1:
		return cpu_player_easy(board, player)
	if difficulty == 2:
		return cpu_player_medium(board, player)
	if difficulty == 3:
		return cpu_player_hard(board, player, iter_count)


if __name__ == "__main__":
	main()




